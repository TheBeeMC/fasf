![spaaace](https://cloud.githubusercontent.com/assets/3951311/21784604/ffc2d282-d6c4-11e6-97f0-0ada12c4fab7.gif)

# Spaaace
An online HTML5 multiplayer space shooter built with [Lance](http://lance.gg) game server

[Play now!](http://spaaace.herokuapp.com)
