#!/bin/bash
pkill -f spaaace || true

